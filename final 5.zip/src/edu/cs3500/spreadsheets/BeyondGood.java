package edu.cs3500.spreadsheets;

import edu.cs3500.spreadsheets.model.IWorkSheetModel;
import edu.cs3500.spreadsheets.model.WorkSheetModel;
import edu.cs3500.spreadsheets.model.WorksheetReader;
import edu.cs3500.spreadsheets.model.WorksheetReader.WorksheetBuilder;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 * The main class for our program.
 */
public class BeyondGood {

    /**
     * The main entry point.
     *
     * @param args any command-line arguments
     */
    public static void main(String[] args) {
    /*
      TODO: For now, look in the args array to obtain a filename and a cell name,
      - read the file and build a model from it, 
      - evaluate all the cells, and
      - report any errors, or print the evaluated value of the requested cell.
    */

        if (validArgs(args)) {
            File file = new File(args[1]);


            // Use WorksheetReader.read() to build model
            try {
                Readable fileReader = new FileReader(file);
                WorksheetBuilder<IWorkSheetModel> builder = new WorkSheetModel.SheetBuilder();
                IWorkSheetModel model = WorksheetReader.read(builder, fileReader);
                if (!model.hasErrors()) {
                    model.evaluateIndCell(args[3]);

                }
            } catch (FileNotFoundException e) {
                System.out.println("No file provided");
            }
        }
    }

    // Validates input arguments
    private static boolean validArgs(String[] args) {
        if (args == null || args.length != 4 ||
                !(args[0].equals("-in") && args[2].equals("-eval"))) {
            System.out.println("Null or incorrect number of arguments");
            return false;
        }
        return true;
    }
}
