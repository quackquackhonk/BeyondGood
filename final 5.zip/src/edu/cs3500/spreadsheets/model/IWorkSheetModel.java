package edu.cs3500.spreadsheets.model;

import java.util.HashSet;

/**
 * To represent a model for a worksheet. Maintains state and enforces class invariants.
 */
public interface IWorkSheetModel<CellContents> {

    /**
     * Replaces cell at the given location with the cell created from the provided value.
     *
     * @param location is the coordinates of the cell
     * @param value    is the row input, parsable as an s-expression
     */
    void updateCell(Coord location, String value);

    /**
     * Returns the set of Coords initiated or depended on by other Coords.
     *
     * @return active Coords
     */
    HashSet<Coord> activeCells();

    /**
     * Prints result of evaluated cell at given coordinate.
     *
     * @param coord
     */
    String evaluateCell(String coord);

    /**
     * Returns the raw text of the cell at given Coordinate.
     *
     * @param coord
     */
    String getCellText(Coord coord);


    /**
     * Prints result of evaluated cell at given coordinate.
     *
     * @param coord
     */
    void evaluateIndCell(String coord);

    /**
     * Does the model have any cells in error?
     */
    Boolean hasErrors();

    /**
     * Shifts given cell contents based on x and y axis.
     */
    void shiftCells(CellContents c, int x, int y);

    /**
     * Applies origin cell to all cells within range.
     */
    void dragChange(Coord start, Coord finish);

//  /**
//   * Replaces cell at the given location with the cell.
//   *
//   * @param location is the coordinates of the cell
//   * @param cell     is the cell to be set
//   */
//  void setCell(Coord location, Cell cell);

    /**
     * Return cell at a provided location.
     *
     * @param location is the coordinates of the cell
     * @return the {@Cell} at the provided location
     * @throws IllegalStateException    if the model was not checked
     * @throws IllegalArgumentException if the location of the cell is invalid
     */
    CellContents getCell(Coord location) throws IllegalStateException;


    /**
     * Checks the validity of the model.
     */
    void setupModel();

    /**
     * Build a cell at a given location provided with col and row numbers.
     *
     * @param col      represents the col number
     * @param row      represents the row number
     * @param contents the content of the cell
     * @throws IllegalStateException    if the model was not checked
     * @throws IllegalArgumentException if the location of the cell is invalid
     */
    void buildCell(int col, int row, CellContents contents);

    /**
     * Sets a cell given raw String containing a coordinate and raw cell contents
     */
    void setCell(int col, int row, String s);

    /**
     * Returns the width of the row.
     *
     * @return the width of the row
     */
    int getRowWidth();

    /**
     * Returns the height of the col.
     *
     * @return the height of the col
     */
    int getColHeight();
}
