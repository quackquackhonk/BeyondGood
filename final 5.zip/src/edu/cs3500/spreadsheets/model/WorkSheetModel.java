package edu.cs3500.spreadsheets.model;

import edu.cs3500.spreadsheets.model.WorksheetReader.WorksheetBuilder;
import edu.cs3500.spreadsheets.sexp.Parser;
import edu.cs3500.spreadsheets.sexp.Sexp;

import java.util.*;

/**
 * Model class for working with spreadsheets.
 */
public class WorkSheetModel implements IWorkSheetModel<CellContents> {

    HashMap<Coord, CellContents> sheet;
    HashMap<Coord, ArrayList<HashSet<Coord>>> adjList;
    boolean isValid;
    int numRow;
    int numCol;

    /**
     * Creates a WorkSheetModel for evaluating and editing spreadsheets.
     */
    public WorkSheetModel() {
        this.sheet = new HashMap<>();
        this.adjList = new HashMap<>();
    }

    protected HashMap<Coord, ArrayList<HashSet<Coord>>> getAdjList() {
        return this.adjList;
    }

    // Returns whether or not model has problematic cells in model.
    @Override
    public Boolean hasErrors() {
        Boolean publicVal = this.isValid;
        return publicVal;
    }

    /**
     * Shifts given cell contents based on x and y axis.
     *
     * @param c
     * @param x
     * @param y
     */
    @Override
    public void shiftCells(CellContents c, int x, int y) {

    }

    /**
     * Applies origin cell to all cells within range.
     *
     * @param start
     * @param finish
     */
    @Override
    public void dragChange(Coord start, Coord finish) {

    }

    /**
     * Replaces cell at the given location with the cell created from the provided value.
     *
     * @param location is the coordinates of the cell
     * @param value    is the row input, parsable as an s-expression
     */
    @Override
    public void updateCell(Coord location, String value) {

    }

    /**
     * Prints result of evaluated cell at given coordinate.
     *
     * @param coord
     */
    @Override
    public String evaluateCell(String coord) {
        try {
            Coord target = getCoordFromString(coord);
            CellContents cell = getCell(target);
            Value finalVal = cell.acceptEvalVisitor(new EvalVisitor());
            //System.out.println(coord + " evaluated to " + finalVal.toString());
            return finalVal.toString();
        } catch (NullPointerException n) {
            throw new IllegalArgumentException("Can't evaluate cell or cell doesn't exist");
        }

//    System.out.println(finalVal.toString());
    }

    /**
     * Returns the raw text of the cell at given Coordinate.
     *
     * @param coord
     */
    @Override
    public String getCellText(Coord coord) {
        CellContents cell = getCell(coord);
        if (cell == null) {
            return null;
        } else {
            return cell.getRaw();
        }
    }

    @Override
    public void evaluateIndCell(String coord) {
        Coord target = getCoordFromString(coord);
        CellContents cell = getCell(target);
        Value finalVal = cell.acceptEvalVisitor(new EvalVisitor());
//    System.out.println(coord + " evaluated to " + finalVal.toString());
        System.out.print(finalVal.toString());
    }

    /**
     * Return cell at a provided location.
     *
     * @param loc is the coordinates of the cell
     * @return the {@code CellContents} at the provided location
     * @throws IllegalStateException    if the model was not checked
     * @throws IllegalArgumentException if the location of the cell is invalid
     */
    @Override
    public CellContents getCell(Coord loc) throws IllegalArgumentException {
        try {
            return this.sheet.get(loc);
        } catch (NullPointerException e) {
            return null;
        }

    }

    /**
     * returns the Coords in this model.
     */
    @Override
    public HashSet<Coord> activeCells() {
        return new HashSet<Coord>(this.sheet.keySet());
    }

    /**
     * Checks the validity of all cells in the worksheet by parsing their s-expressions.
     *
     * @param toSkip - Cycle cells caught in checkAdjList();
     * @return rest of the bad cells
     */

    protected HashSet<Coord> checkGrid(HashSet<Coord> toSkip) {
        HashSet<Coord> badCells = new HashSet<>();
        Set<Coord> toCheck = this.sheet.keySet();
        // Remove cells that had cycles.
        for (Coord c : toSkip) {
            toCheck.remove(c);
        }

        // Evaluate every cell, accumulate the bad ones.
        // Returns the bad ones.
        for (Coord c : toCheck) {
            try {
                if (getCell(c) != null) {
                    evaluateCell(c.toString());
                } else {
                    String strCoord = c.toString();
                    SexpVisitParser coordParser = new SexpVisitParser();
                    String[] coordComps = coordParser.checkCoord(strCoord);

                    buildCell(Coord.colNameToIndex(coordComps[0]), Integer.parseInt(coordComps[1]), null);
                }
            } catch (IllegalArgumentException e) {
                badCells.add(c);
            }
        }
        return badCells;
    }


    /**
     * Checks evaluable cells and cyclic references.
     */
    @Override
    public void setupModel() {
        this.buildAdjList();
        HashSet<Coord> cycleCells = this.checkAdjList();
        HashSet<Coord> badEvalCells = this.checkGrid(cycleCells);

        // Do problem cells exist?
        isValid = cycleCells.size() > 0 || badEvalCells.size() > 0;
        for (Coord c : cycleCells) {
            System.out.println("Error in cell: " + c.toString() + ": Was in cycle");
        }

        for (Coord c : badEvalCells) {
            System.out.println("Error in cell: " + c.toString() + ": Could not be evaluated");
        }
    }

    // Checks adjacency list for cycles
    protected HashSet<Coord> checkAdjList() {
        Set<Coord> needCheck = this.adjList.keySet();
        HashSet<Coord> allProbCells = new HashSet<>();

        // Gets all cells in a cycle starting with cur cell.
        // Adds them to allProbCells, removes them from needCheck.
        for (Coord cur : needCheck) {
            // Only check if haven't seen before, as part of DFS.
            if (!allProbCells.contains(cur) && getCell(cur) != null) {
                HashSet<Coord> curProbCells = getProbCells(cur);
                allProbCells.addAll(curProbCells);
            }
        }
    /*
    for(Coord bad : allProbCells) {
      System.out.println(bad.toString() + " is in a cycle");
    }
     */
        return allProbCells;
    }

    // Returns all cells that are in a cycle with origin. Can be empty Set.
    protected HashSet<Coord> getProbCells(Coord origin) {
        Stack<Coord> visited = new Stack<>();
        HashSet<Coord> output = new HashSet<>();
        Stack<Coord> todo = new Stack<>();

        // Add origin to visited, push origin's dependencies to todo.
        visited.push(origin);
        HashSet<Coord> origDep = this.adjList.get(origin).get(1);
        boolean isCycle = false;
        for (Coord c : origDep) {
            todo.push(c);
        }

        //System.out.println(todo + visited.toString());
        // Loops until a cycle is found or all Coords checked.
        while (!todo.empty() && !isCycle) {
            Coord toCheck = todo.pop();
      /*visited.search(toCheck) != -1
      if(getCell(toCheck) == null) {
        String strCoord = toCheck.toString();
        SexpVisitParser coordParser = new SexpVisitParser();
        String[] coordComps = coordParser.checkCoord(strCoord);

        buildCell(Coord.colNameToIndex(coordComps[0]), Integer.parseInt(coordComps[1]), null);
      }

       */
            if (!adjList.get(toCheck).get(1).contains(toCheck)) {
                HashSet<Coord> newDep = this.adjList.get(toCheck).get(1);
                for (Coord c : newDep) {
                    todo.push(c);
                }

                // Backtracks by popping from visited.

                if (visited.search(toCheck) != -1) {
                    isCycle = true;
                    output.addAll(visited);
                    for (Coord c : visited) {
                        HashSet<Coord> children = this.adjList.get(c).get(0);
                        output.addAll(children);
                    }
                    break;
                }
                visited.push(toCheck);
            } else {
                visited.pop();
            }
        }
        // Returns list of cells affected by cycle. Can be empty.
        return output;
    }

    /**
     * Build a cell at a given location provided with col and row numbers.
     *
     * @param col  represents the col number
     * @param row  represents the row number
     * @param cont the content of the cell
     * @return the {@code CellContents} at the provided location
     * @throws IllegalStateException    if the model was not checked
     * @throws IllegalArgumentException if the location of the cell is invalid
     */
    @Override
    public void buildCell(int col, int row, CellContents cont) {
        Coord coord = new Coord(col, row);
        this.sheet.put(coord, cont);
        ArrayList<HashSet<Coord>> childDeps = new ArrayList<>();
        childDeps.add(new HashSet<>());
        childDeps.add(new HashSet<>());
        this.adjList.put(coord, childDeps);
    }

    /*
     * Creates and sets a cell at coordinate in input string if valid.
     * -Create cell, store old one.
     * - get dependencies of new cell
     * - Get children of setCell's coord if has any
     * - Check for cycles
     * - If no cycles, evaluate itself
     *    - if works, evaluate children to make sure it works
     *
     * - replace cell
     */
    @Override
    public void setCell(int col, int row, String cellString) {
        Coord coord = new Coord(col, row);
        if (cellString == null) {
            buildCell(col, row, null);
        } else {
            CellContents newCell = SheetBuilder.cellFromString(cellString);

            Set<Coord> keys = this.sheet.keySet();
            boolean coordExists = keys.contains(coord);
            // Current Dependencies or none.
            HashSet<Coord> curDeps = coordExists ? this.adjList.get(coord).get(1) : new HashSet<Coord>();
            HashSet<Coord> curChild = coordExists ? this.adjList.get(coord).get(0) : new HashSet<Coord>();
            CellContents oldCell = getCell(coord);
            HashSet<Coord> newDeps = this.getDepCoords(cellString);

            // Set new dependencies to check for cycles.
            this.adjList.get(coord).set(1, newDeps);
            this.sheet.put(coord, newCell);

            HashSet<Coord> cycleCells = this.getProbCells(coord);
            if (cycleCells.size() == 0) {
                try {
                    // Evaluate current cell
                    newCell.acceptEvalVisitor(new EvalVisitor());
                    HashSet<Coord> needCheck = new HashSet<>(newDeps);
                    needCheck.addAll(curChild);

                    // Only check children and dependencies of Coord skip rest.
                    HashSet<Coord> dontCheck = new HashSet<>(this.sheet.keySet());
                    dontCheck.removeAll(needCheck);

                    HashSet<Coord> probEvalCells = this.checkGrid(dontCheck);
                    // If cells can't evaluate, put old cell/dependencies back.
                    if (!(probEvalCells.size() == 0)) {
                        this.sheet.put(coord, oldCell);
                        this.adjList.get(coord).set(1, curDeps);
                        throw new IllegalArgumentException("New cell messes up old cells");
                    }
                    //System.out.println("Successfully added " + coord.toString());
                } catch (IllegalArgumentException e) {
                    throw new IllegalArgumentException("New cell can't evaluate");
                }
            } else {
                throw new IllegalArgumentException("New cell has a cycle");
            }
        }
    }

    @Override
    public int getRowWidth() {
        return 0;
    }

    @Override
    public int getColHeight() {
        return 0;
    }

    // Builds adjacency list for all cells in sheet.
    protected void buildAdjList() {
        Set<Coord> toCheck = this.sheet.keySet();

        // Gets Coord dependencies of currentCoord
        for (Coord currentCoord : toCheck) {
            CellContents cellContent = this.getCell(currentCoord);
            if (cellContent != null) {
                String cellRaw = cellContent.getRaw();
                ArrayList<HashSet<Coord>> childDeps = this.adjList.get(currentCoord);

                // Set dependencies of currentCoord
                HashSet<Coord> dep = this.getDepCoords(cellRaw);
                childDeps.set(1, dep);

                // Adds currentCoord as child of its dependencies
                for (Coord coordDep : dep) {
                    if (getCell(coordDep) != null) {
                        ArrayList<HashSet<Coord>> neighbors = this.adjList.get(coordDep);
                        HashSet<Coord> children = neighbors.get(0);
                        children.add(currentCoord);
                    } else {
                        // If a dependency of currentCoord hasn't been created yet, set it as null
                        // and add currentCoord as a child.
                        String strCoord = coordDep.toString();
                        SexpVisitParser coordParser = new SexpVisitParser();
                        String[] coordComps = coordParser.checkCoord(strCoord);
                        buildCell(Coord.colNameToIndex(coordComps[0]), Integer.parseInt(coordComps[1]), null);
                        this.adjList.get(coordDep).get(0).add(currentCoord);
                    }
                }
            }
        }
    }

    // Builds Coords from input String and returns them in list.
    // Can be empty.
    private HashSet<Coord> getDepCoords(String cellRaw) {
        String[] cellRowArray = cellRaw.split(" ");
        HashSet<Coord> coords = new HashSet<>();
        SexpVisitParser coordParser = new SexpVisitParser();

        for (String c : cellRowArray) {
            if (!c.contains("\"")) {
                try {
                    String[] coordComps = coordParser.checkCoord(c);
                    int col = Coord.colNameToIndex(coordComps[0]);
                    int row = Integer.parseInt(coordComps[1]);
                    Coord toAdd = new Coord(col, row);
                    coords.add(toAdd);
                } catch (IllegalArgumentException e) {
                    // TODO: figure out what to put here
                }
            }
        }
        return coords;
    }

    // Builds Coords from input String and returns it.
    // Can be empty.
    private Coord getCoordFromString(String cellRaw) {
        String[] cellRowArray = cellRaw.split(" ");
        HashSet<Coord> coords = new HashSet<>();
        SexpVisitParser coordParser = new SexpVisitParser();

        for (String c : cellRowArray) {
            if (!c.contains("\"")) {
                try {
                    String[] coordComps = coordParser.checkCoord(c);
                    int col = Coord.colNameToIndex(coordComps[0]);
                    int row = Integer.parseInt(coordComps[1]);
                    Coord toAdd = new Coord(col, row);
                    return toAdd;
                } catch (IllegalArgumentException e) {
                    // TODO: figure out what to put here
                }
            }
        }
        throw new IllegalArgumentException("invalid coord");
    }

    /**
     * A factory class to build model.
     */
    public static final class SheetBuilder implements
            WorksheetReader.WorksheetBuilder<IWorkSheetModel> {

        IWorkSheetModel model;

        /**
         * A factory class to build model.
         *
         * @param model represent a worksheet model
         */
        public SheetBuilder(IWorkSheetModel model) {
            this.model = model;
        }

        /**
         * A factory class to build model.
         */
        public SheetBuilder() {
            this.model = new WorkSheetModel();
        }

        // Creates cell from raw string input with equls.
        // Throws IAE if string can't be made into a cell.
        public static CellContents cellFromString(String contents) throws IllegalArgumentException {
            try {
                String toParse;
                CellContents cell;
                String first = contents.substring(0, 1);
                // Parses CellContents if equal sign seen
                if (first.equals("=")) {
                    toParse = contents.substring(1);
                    Sexp parsed = Parser.parse(toParse);
                    SexpVisitParser visitParser = new SexpVisitParser();
                    cell = parsed.accept(visitParser);
                    // No SSymbols allowed if not preceded by "="
                } else {
                    Sexp parsed = Parser.parse((contents));
                    SexpVisitParserSymbol visitParser = new SexpVisitParserSymbol();
                    cell = parsed.accept(visitParser);
                }
                return cell;
            } catch (IllegalArgumentException e) {
                //System.out.println(contents);
                throw new IllegalArgumentException(e);
            }
        }

        /**
         * Creates a new cell at the given coordinates and fills in its raw contents.
         *
         * @param col      the column of the new cell (1-indexed)
         * @param row      the row of the new cell (1-indexed)
         * @param contents the raw contents of the new cell: may be {@code null}, or any string. Strings
         *                 beginning with an {@code =} character should be treated as formulas; all
         *                 other strings should be treated as number or boolean values if possible, and
         *                 string values otherwise.
         * @return this {@link WorksheetBuilder}
         */
        @Override
        public SheetBuilder createCell(int col, int row, String contents) {
            try {
                String toParse;
                CellContents cell = cellFromString(contents);
                this.model.buildCell(col, row, cell);

            } catch (IllegalArgumentException e) {
                // Catch IAE thrown by parser
                System.out.println("Error in cell " +
                        Coord.colIndexToName(col) + row + ": Unparsable Sexpression");
            }
            return new SheetBuilder(this.model);
        }


        @Override
        public IWorkSheetModel createWorksheet() {
            this.model.setupModel();
            return this.model;
        }
    }

    /*
    Visitor for evaluating CellContents.
     */
    public final class EvalVisitor implements IEvalVisitor<Value> {

        /*
        Returns this CellContents as an ArrayList.
         */
        public ArrayList<CellContents> getContentBool(Bool b) {
            ArrayList<CellContents> arr = new ArrayList<>();
            arr.add(b);
            return arr;
        }

        /*
         * Returns this CellContents as an ArrayList.
         */
        public ArrayList<CellContents> getContentStr(Str b) {
            ArrayList<CellContents> arr = new ArrayList<>();
            arr.add(b);
            return arr;
        }

        /*
         * Returns this CellContents as an ArrayList.
         */
        public ArrayList<CellContents> getContentDbl(Dbl b) {
            ArrayList<CellContents> arr = new ArrayList<>();
            arr.add(b);
            return arr;
        }

        /*
         * Returns this CellContents as an ArrayList.
         */
        public ArrayList<CellContents> getContentRefCell(ReferenceCell b) {
            ArrayList<Coord> coords = b.evaluate();
            ArrayList<CellContents> cells = new ArrayList<>();
            coords.forEach((c) -> cells.add(WorkSheetModel.this.getCell(c)));
            return cells;
        }

        /*
         * Returns this CellContents as an ArrayList.
         */
        public ArrayList<CellContents> getContentSum(SUM b) {
            ArrayList<CellContents> evaled = new ArrayList<>();
            evaled.add(b.acceptEvalVisitor(this));
            return evaled;
        }

        /*
         * Returns this CellContents as an ArrayList.
         */
        public ArrayList<CellContents> getContentProduct(PRODUCT b) {
            ArrayList<CellContents> evaled = new ArrayList<>();
            evaled.add(b.acceptEvalVisitor(this));
            return evaled;
        }

        /*
         * Returns this CellContents as an ArrayList.
         */
        public ArrayList<CellContents> getContentLess(LESSTHAN b) {
            ArrayList<CellContents> evaled = new ArrayList<>();
            evaled.add(b.acceptEvalVisitor(this));
            return evaled;
        }

        /*
         * Returns this CellContents as an ArrayList.
         */
        public ArrayList<CellContents> getContentGreater(GREATERTHAN b) {
            ArrayList<CellContents> evaled = new ArrayList<>();
            evaled.add(b.acceptEvalVisitor(this));
            return evaled;
        }

        /**
         * Returns boolean of Bool
         *
         * @param b
         */
        @Override
        public Value visitBool(Bool b) {
            return b;
        }

        /**
         * Returns String of Str
         *
         * @param s
         */
        @Override
        public Value visitStr(Str s) {
            return s;
        }

        /**
         * Returns double of Dbl
         *
         * @param d
         */
        @Override
        public Value visitDbl(Dbl d) {
            return d;
        }

        /**
         * Returns evaluated cell if single reference, throws an error for regions of cells.
         *
         * @param r reference cell to evaluate.
         * @return returns ReferenceCell
         */
        @Override
        public Value visitRefCell(ReferenceCell r) {
            ArrayList<Coord> contCoord = r.evaluate();
            if (contCoord.size() > 1) {
                throw new IllegalArgumentException("Can't evaluate multiple cells without a formula");
            } else {
                CellContents cellCont = WorkSheetModel.this.getCell(contCoord.get(0));
                if (cellCont.equals(r)) {
                    throw new IllegalArgumentException("Cell can't refer to itself");
                }
                return cellCont.acceptEvalVisitor(this);
            }
        }

        /**
         * Returns sum of contents.
         *
         * @param s
         */
        @Override
        public Dbl visitSUM(SUM s) {
            double total = 0;
            ArrayList<CellContents> cont = s.getInnerCells();
            if (cont.size() == 1) {
                CellContents single = cont.get(0);
                ArrayList<CellContents> singleCont = single.forOps(this);

                for (int i = 0; i < singleCont.size(); i++) {
                    if (singleCont.get(i) == null) {
                        singleCont.set(i, new Dbl(0));
                    }
                }

                if (singleCont.size() == 1) {
                    return singleCont.get(0).acceptEvalVisitor(this).getDbl();
                } else {
                    SUM rangeSum = new SUM(singleCont);
                    return rangeSum.acceptEvalVisitor(this).getDbl();
                }
            } else {
                for (CellContents c : cont) {
                    SUM toAdd = new SUM(c.forOps(this));
                    Dbl dblAdd = toAdd.acceptEvalVisitor(this).getDbl();
                    total += dblAdd.evaluate();
                }
            }
//      System.out.println("Summed to " + new Dbl(total).toString());
            return new Dbl(total);
        }

        /**
         * Returns product of contents
         *
         * @param s
         */
        @Override
        public Value visitPRODUCT(PRODUCT s) {
            double total = 1;
            ArrayList<CellContents> cont = s.getInnerCells();
            if (cont.size() == 1) {
                CellContents single = cont.get(0);
                ArrayList<CellContents> singleCont = single.forOps(this);
                if (singleCont.size() == 1) {
                    return singleCont.get(0).acceptEvalVisitor(this).getDbl();
                } else {
                    PRODUCT rangeProd = new PRODUCT(singleCont);
                    return rangeProd.acceptEvalVisitor(this).getDbl();
                }
            } else {
                for (CellContents c : cont) {
                    PRODUCT toMult = new PRODUCT(c.forOps(this));
                    Dbl dblMult = toMult.acceptEvalVisitor(this).getDbl();
                    total *= dblMult.evaluate();
                }
            }
//      System.out.println("Product is " + new Dbl(total).toString());
            return new Dbl(total);
        }

        /**
         * Returns if first argument is greater than second argument. (numeric inputs)
         *
         * @param s
         */
        @Override
        public Value visitGREATERTHAN(GREATERTHAN s) {
            ArrayList<CellContents> cont = s.getInnerCells();
            // base case if two values to compare.
            if (cont.size() == 2) {
                CellContents first = cont.get(0);
                ArrayList<CellContents> firstCont = first.forOps(this);
                CellContents second = cont.get(1);
                ArrayList<CellContents> secCont = second.forOps(this);
                if (firstCont.size() == 1 && secCont.size() == 1) {
                    Dbl num1 = firstCont.get(0).acceptEvalVisitor(this).getDbl();
                    Dbl num2 = secCont.get(0).acceptEvalVisitor(this).getDbl();
                    boolean result = num1.evaluate() > num2.evaluate();
//          System.out.println("Result of GREATERTHAN is " + result);
                    return new Bool(result);
                } else {
                    Value val1 = first.acceptEvalVisitor(this);
                    Value val2 = first.acceptEvalVisitor(this);
                    ArrayList<CellContents> lessParams = new ArrayList<>();
                    lessParams.add(val1);
                    lessParams.add(val2);
                    LESSTHAN newLess = new LESSTHAN(lessParams);
                    return newLess.acceptEvalVisitor(this);
                }
            } else {
                throw new IllegalArgumentException("Incorrect number of parameters");
            }
        }

        /**
         * Returns if first argument is less than second argument. (numeric inputs)
         *
         * @param s
         */
        @Override
        public Value visitLESSTHAN(LESSTHAN s) {
            ArrayList<CellContents> cont = s.getInnerCells();
            // base case if two values to compare.
            if (cont.size() == 2) {
                CellContents first = cont.get(0);
                ArrayList<CellContents> firstCont = first.forOps(this);
                CellContents second = cont.get(1);
                ArrayList<CellContents> secCont = second.forOps(this);

                if (firstCont.size() == 1 && secCont.size() == 1) {
                    Dbl num1 = firstCont.get(0).acceptEvalVisitor(this).getDbl();
                    Dbl num2 = secCont.get(0).acceptEvalVisitor(this).getDbl();
                    boolean result = num1.evaluate() < num2.evaluate();
//          System.out.println("Result of LESSTHAN is " + result);
                    return new Bool(result);
                } else {
                    Value val1 = first.acceptEvalVisitor(this);
                    Value val2 = first.acceptEvalVisitor(this);
                    ArrayList<CellContents> lessParams = new ArrayList<>();
                    lessParams.add(val1);
                    lessParams.add(val2);
                    LESSTHAN newLess = new LESSTHAN(lessParams);
                    return newLess.acceptEvalVisitor(this);
                }
            } else {
                throw new IllegalArgumentException("Incorrect number of parameters");
            }
        }

        // Returns single size ArrayList of the base case or
        // returns ArrayList of CellContents otherwise.
        protected ArrayList<CellContents> evalOps(CellContents cell) {
            ArrayList<CellContents> cont = cell.forOps(this);
            if (cont.size() == 1) {
                CellContents single = cont.get(0);
                if (single.forOps(this).get(0).equals(single)) {
                    ArrayList<CellContents> singleList = new ArrayList<>();
                    singleList.add(single);
                    return singleList;
                } else {
                    CellContents toEval = (CellContents) single.forOps(this).get(0);
                    return evalOps(toEval);
                }
            } else {
                return cont;
            }
        }
    }
}

