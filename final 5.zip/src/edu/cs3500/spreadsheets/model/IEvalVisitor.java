package edu.cs3500.spreadsheets.model;

/*
 * An abstracted function object for evaluating cells,
 * @param The return type of the function
 */
public interface IEvalVisitor<Value> {
    /**
     * Returns boolean of Bool
     */
    Value visitBool(Bool b);

    /**
     * Returns String of Str
     */
    Value visitStr(Str s);

    /**
     * Returns double of Dbl
     */
    Value visitDbl(Dbl d);

    /**
     * Returns evaluated cell if single reference, throws an error for regions of cells.
     */
    Value visitRefCell(ReferenceCell r);

    /**
     * Returns sum of contents.
     */
    Value visitSUM(SUM s);

    /**
     * Returns product of contents
     */
    Value visitPRODUCT(PRODUCT p);

    /**
     * Returns if first argument is greater than second argument. (numeric inputs)
     */
    Value visitGREATERTHAN(GREATERTHAN g);

    /**
     * Returns if first argument is less than second argument. (numeric inputs)
     */

    Value visitLESSTHAN(LESSTHAN l);
}
