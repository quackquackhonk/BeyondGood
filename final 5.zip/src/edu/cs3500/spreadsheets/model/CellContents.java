package edu.cs3500.spreadsheets.model;

import java.util.ArrayList;

public interface CellContents<k> {

    /**
     * Returns value of CellContents. Value refers to the data type of the class, ex: Bool returns a
     * boolean.
     */
    k evaluate();

    /**
     * Returns the string implementation of cell contents.
     */
    String getRaw();

    /**
     * Evaluates current cell to its base Value.
     *
     * @param v the visitor used to evaluate cell
     * @return base Value of cell.
     */
    Value acceptEvalVisitor(WorkSheetModel.EvalVisitor v);

    /**
     * Returns the contents of the given cell in an ArrayList.
     *
     * @param v
     * @return
     */
    ArrayList<CellContents> forOps(WorkSheetModel.EvalVisitor v);


}
